The entity type we had chosen is person names and names are marked up using the tag </>. For example, Jack is marked up as <Jack/>
