We chose to mark up person names in ESPN documents. We marked them using the tag </>. For example, the name Jack is marked up \<Jack/\>.
